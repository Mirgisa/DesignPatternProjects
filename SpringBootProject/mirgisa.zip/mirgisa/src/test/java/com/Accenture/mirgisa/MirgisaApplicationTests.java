package com.Accenture.mirgisa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MirgisaApplicationTests {

	@Test
	void contextLoads() {
	}

}
