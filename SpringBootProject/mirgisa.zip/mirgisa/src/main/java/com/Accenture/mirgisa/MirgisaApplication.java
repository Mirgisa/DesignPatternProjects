package com.Accenture.mirgisa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MirgisaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MirgisaApplication.class, args);
	}

}
